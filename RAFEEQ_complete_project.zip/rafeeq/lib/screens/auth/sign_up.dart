import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:provider/provider.dart';
import '../../core/providers/app_provider.dart';

class SignUpScreen extends StatelessWidget {
  const SignUpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final name = TextEditingController();
    final email = TextEditingController();
    final phone = TextEditingController();
    final pass = TextEditingController();
    UserRole roleChoice = UserRole.student;

    return Scaffold(
      appBar: AppBar(title: const Text('Create Account')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Choose role'),
          Row(children: [
            Expanded(child: RadioListTile<UserRole>(value: UserRole.student, groupValue: roleChoice, onChanged: (v){ roleChoice = v!; }, title: const Text('Student'))),
            Expanded(child: RadioListTile<UserRole>(value: UserRole.provider, groupValue: roleChoice, onChanged: (v){ roleChoice = v!; }, title: const Text('Provider'))),
          ]),
          const SizedBox(height: 8),
          TextField(controller: name,
              decoration: const InputDecoration(labelText: 'Full name', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: email,
              decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          IntlPhoneField(controller: phone,
              decoration: const InputDecoration(labelText: 'Phone number', border: OutlineInputBorder()),
              initialCountryCode: 'JO'),
          const SizedBox(height: 12),
          TextField(controller: pass, obscureText: true,
              decoration: const InputDecoration(labelText: 'Password (8+ strong)', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          FilledButton(onPressed: (){ context.read<AppState>().setRole(roleChoice); Navigator.pop(context); }, child: const Text('Sign Up')),
        ],
      ),
    );
  }
}
